// onlined.app
// manages user-related socket.io actions

export async function launch(FS, UI, core) {
    var messages = {
        checkIfOpen: function () {
            return {existing: false}
        },
        registerNewWin: function () {
            
        },
        releaseWin: function () {
            
        }
    }

    core.onlined.messages = messages;
}
export var name = "Setup";

export async function launch(FS, UI, core) {
    const backgroundDiv = UI.create('div', document.body, 'setup-flex-container');
    const styles = UI.create('style', backgroundDiv, 'hide');
    styles.textContent = `.setup-flex-container {
    position: fixed;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgba(var(--ui-primary), 0.1);
    -webkit-backdrop-filter: blur(var(--main-ui-blur));
    backdrop-filter: blur(var(--main-ui-blur));
    padding: 20px;
}

.setup-window {
    width: 600px;
    height: 400px;
    background-color: rgba(var(--ui-primary), 1);
    border: 1px solid rgba(var(--ui-secondary), 1.0);
    border-radius: var(--round-main);
    box-shadow: var(--big-shadow);
    padding: 20px;
    overflow: auto;
    max-width: 95% !important;
    max-height: 95% !important;
}`
    const div = UI.create('div', backgroundDiv, 'setup-window');
    const container = UI.create('div', div, 'window-content');
    var pane;
    const panes = {
        welcome: async function () {
            const newPane = UI.create('pane');
            await UI.img('/system/img/webdesk.png', newPane);
            UI.text('Welcome to WebDesk!', newPane, 'bold');
        }
    }
}